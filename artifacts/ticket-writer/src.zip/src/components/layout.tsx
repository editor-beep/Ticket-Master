import { Link, useLocation } from "wouter";
import { Terminal, History, Plus } from "lucide-react";
import { useGetTicketStats } from "@workspace/api-client-react";
import { useEffect } from "react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { data: stats } = useGetTicketStats();

  useEffect(() => {
    // Force dark mode for IDE vibe
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background w-full">
      <aside className="w-full md:w-64 border-r border-border bg-card flex flex-col">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <Terminal className="w-5 h-5 text-primary" />
          <span className="font-mono font-bold text-sm tracking-tight text-foreground">
            REPLIT_AGENT<span className="text-primary">.sh</span>
          </span>
        </div>
        
        <nav className="flex-1 p-4 flex flex-col gap-2">
          <Link 
            href="/"
            className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors text-sm font-medium ${
              location === "/" 
                ? "bg-primary/10 text-primary" 
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            }`}
            data-testid="link-home"
          >
            <Plus className="w-4 h-4" />
            New Ticket
          </Link>
          <Link 
            href="/history"
            className={`flex items-center justify-between px-3 py-2 rounded-md transition-colors text-sm font-medium ${
              location.startsWith("/history") || location.startsWith("/ticket")
                ? "bg-primary/10 text-primary" 
                : "text-muted-foreground hover:text-foreground hover:bg-muted"
            }`}
            data-testid="link-history"
          >
            <div className="flex items-center gap-2">
              <History className="w-4 h-4" />
              History
            </div>
            {stats !== undefined && (
              <span className="text-xs font-mono bg-muted text-muted-foreground px-1.5 py-0.5 rounded-sm">
                {stats.total}
              </span>
            )}
          </Link>
        </nav>

        <div className="p-4 border-t border-border mt-auto">
          <div className="text-xs font-mono text-muted-foreground flex flex-col gap-1">
            <span>STATUS: <span className="text-green-500">ONLINE</span></span>
            <span>MODE: PRECISION</span>
          </div>
        </div>
      </aside>
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background" />
        <div className="flex-1 overflow-auto relative z-10">
          {children}
        </div>
      </main>
    </div>
  );
}
