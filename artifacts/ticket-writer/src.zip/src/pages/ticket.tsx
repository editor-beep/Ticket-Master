import { useRoute, useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { useGetTicket, useDeleteTicket, getGetTicketQueryKey, getListTicketsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Loader2, Trash2, ArrowLeft, Copy, Check } from "lucide-react";
import { useState } from "react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

export function TicketPage() {
  const [, params] = useRoute("/ticket/:id");
  const id = Number(params?.id);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);
  
  const { data: ticket, isLoading } = useGetTicket(id, {
    query: {
      enabled: !!id,
      queryKey: getGetTicketQueryKey(id)
    }
  });

  const deleteMutation = useDeleteTicket();

  const handleDelete = async () => {
    try {
      await deleteMutation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getListTicketsQueryKey() });
      toast({ title: "Deleted", description: "Ticket removed from history." });
      setLocation("/history");
    } catch (e) {
      toast({ title: "Error", description: "Failed to delete ticket.", variant: "destructive" });
    }
  };

  const handleCopy = () => {
    if (!ticket) return;
    navigator.clipboard.writeText(ticket.generatedTicket);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied", description: "Ticket copied to clipboard." });
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-full">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!ticket) {
    return (
      <Layout>
        <div className="p-6 flex flex-col items-center justify-center h-full">
          <p className="text-muted-foreground font-mono">TICKET_NOT_FOUND</p>
          <Button variant="link" onClick={() => setLocation("/history")} className="mt-4">
            Return to History
          </Button>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-6xl mx-auto w-full p-6 h-full flex flex-col gap-6">
        <header className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex flex-col gap-2">
            <Button 
              variant="ghost" 
              size="sm" 
              className="w-fit -ml-3 text-muted-foreground hover:text-foreground"
              onClick={() => setLocation("/history")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              BACK
            </Button>
            <h1 className="text-2xl font-bold tracking-tight">{ticket.title}</h1>
            <div className="flex items-center gap-3 text-xs font-mono text-muted-foreground">
              <span className="bg-muted px-2 py-1 rounded">ID: {ticket.id}</span>
              <span>{format(new Date(ticket.createdAt), "PP pp")}</span>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              onClick={handleCopy}
              className="font-mono border-border"
              data-testid="button-copy-ticket"
            >
              {copied ? <Check className="w-4 h-4 mr-2 text-green-500" /> : <Copy className="w-4 h-4 mr-2" />}
              {copied ? "COPIED" : "COPY"}
            </Button>
            
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="font-mono" data-testid="button-delete-ticket">
                  <Trash2 className="w-4 h-4 mr-2" />
                  DELETE
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="bg-card border-border">
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete the ticket from the archive.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="font-mono">CANCEL</AlertDialogCancel>
                  <AlertDialogAction onClick={handleDelete} className="font-mono bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    CONFIRM_DELETE
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </header>

        <div className="grid lg:grid-cols-[1fr_2fr] gap-6 flex-1 min-h-0">
          <div className="flex flex-col gap-2">
            <h2 className="text-sm font-medium font-mono text-muted-foreground">ROUGH_INPUT</h2>
            <div className="flex-1 bg-muted/30 border border-border rounded-md p-4 overflow-auto">
              <p className="text-sm whitespace-pre-wrap opacity-80">{ticket.roughInput}</p>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            <h2 className="text-sm font-medium font-mono text-primary flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-primary" />
              GENERATED_TICKET
            </h2>
            <div className="flex-1 bg-card border border-border rounded-md p-4 overflow-auto shadow-sm">
              <pre className="font-mono text-sm whitespace-pre-wrap text-foreground/90">
                {ticket.generatedTicket}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}