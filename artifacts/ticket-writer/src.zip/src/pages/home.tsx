import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useGenerateTicket, useCreateTicket, getListTicketsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Zap, Copy, Save, Check, Terminal } from "lucide-react";

export function Home() {
  const [roughInput, setRoughInput] = useState("");
  const [generatedTicket, setGeneratedTicket] = useState("");
  const [title, setTitle] = useState("");
  const [copied, setCopied] = useState(false);
  
  const generateMutation = useGenerateTicket();
  const createMutation = useCreateTicket();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const handleGenerate = async () => {
    if (!roughInput.trim()) {
      toast({ title: "Input required", description: "Please describe what you want to build.", variant: "destructive" });
      return;
    }
    
    try {
      const res = await generateMutation.mutateAsync({ data: { roughInput } });
      setGeneratedTicket(res.generatedTicket);
      setTitle(res.title);
      toast({ title: "Generation complete", description: "Your ticket is ready." });
    } catch (e) {
      toast({ title: "Generation failed", description: "Something went wrong.", variant: "destructive" });
    }
  };

  const handleSave = async () => {
    if (!generatedTicket || !title || !roughInput) return;
    
    try {
      const res = await createMutation.mutateAsync({
        data: { title, roughInput, generatedTicket }
      });
      queryClient.invalidateQueries({ queryKey: getListTicketsQueryKey() });
      toast({ title: "Saved", description: "Ticket saved to history." });
      setLocation(`/ticket/${res.id}`);
    } catch (e) {
      toast({ title: "Save failed", description: "Could not save the ticket.", variant: "destructive" });
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedTicket);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied", description: "Ticket copied to clipboard." });
  };

  return (
    <Layout>
      <div className="max-w-4xl mx-auto w-full p-6 h-full flex flex-col gap-6">
        <header className="flex flex-col gap-1">
          <h1 className="text-2xl font-bold tracking-tight">Composer</h1>
          <p className="text-muted-foreground text-sm font-mono">Turn rough ideas into precision tickets.</p>
        </header>

        <div className="grid md:grid-cols-2 gap-6 flex-1 min-h-[500px]">
          {/* Input Side */}
          <div className="flex flex-col gap-4">
            <div className="flex-1 flex flex-col gap-2">
              <label className="text-sm font-medium font-mono text-primary flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                INPUT_BUFFER
              </label>
              <Textarea 
                value={roughInput}
                onChange={(e) => setRoughInput(e.target.value)}
                placeholder="Describe your app idea here..."
                className="flex-1 resize-none font-mono text-sm bg-background border-border focus-visible:ring-primary p-4 shadow-inner"
                data-testid="textarea-rough-input"
              />
            </div>
            <Button 
              onClick={handleGenerate}
              disabled={generateMutation.isPending || !roughInput.trim()}
              className="w-full h-12 font-bold tracking-wide"
              data-testid="button-generate"
            >
              {generateMutation.isPending ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  PROCESSING...
                </>
              ) : (
                <>
                  <Zap className="w-5 h-5 mr-2" />
                  GENERATE TICKET
                </>
              )}
            </Button>
          </div>

          {/* Output Side */}
          <div className="flex flex-col gap-4">
            <div className="flex-1 flex flex-col gap-2">
              <label className="text-sm font-medium font-mono text-muted-foreground flex items-center justify-between">
                <span>OUTPUT_BUFFER</span>
                {generatedTicket && (
                  <span className="text-xs text-primary bg-primary/10 px-2 py-0.5 rounded">READY</span>
                )}
              </label>
              
              <div className="flex-1 border border-border bg-card rounded-md flex flex-col overflow-hidden relative shadow-sm">
                {!generatedTicket && !generateMutation.isPending ? (
                  <div className="flex-1 flex items-center justify-center text-muted-foreground text-sm font-mono flex-col gap-2 opacity-50">
                    <Terminal className="w-8 h-8" />
                    <span>AWAITING INPUT</span>
                  </div>
                ) : generateMutation.isPending ? (
                  <div className="flex-1 flex items-center justify-center text-primary flex-col gap-4 font-mono text-sm">
                    <Loader2 className="w-8 h-8 animate-spin" />
                    <span className="animate-pulse">Synthesizing...</span>
                  </div>
                ) : (
                  <>
                    <div className="p-3 border-b border-border bg-muted/30">
                      <Input 
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="h-8 font-mono text-sm bg-transparent border-transparent hover:border-border focus-visible:ring-1 focus-visible:ring-primary px-2"
                        placeholder="Ticket title..."
                        data-testid="input-ticket-title"
                      />
                    </div>
                    <div className="flex-1 overflow-auto p-4">
                      <pre className="font-mono text-sm whitespace-pre-wrap text-foreground/90">
                        {generatedTicket}
                      </pre>
                    </div>
                  </>
                )}
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                className="flex-1 border-border hover:bg-muted hover:text-foreground font-mono"
                disabled={!generatedTicket}
                onClick={handleCopy}
                data-testid="button-copy"
              >
                {copied ? <Check className="w-4 h-4 mr-2 text-green-500" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? "COPIED" : "COPY"}
              </Button>
              <Button 
                className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90 font-mono"
                disabled={!generatedTicket || createMutation.isPending}
                onClick={handleSave}
                data-testid="button-save"
              >
                {createMutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                SAVE
              </Button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}