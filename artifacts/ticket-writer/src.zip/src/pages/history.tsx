import { useState } from "react";
import { useLocation } from "wouter";
import { Layout } from "@/components/layout";
import { useListTickets } from "@workspace/api-client-react";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { Search, FileText, ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export function HistoryPage() {
  const [search, setSearch] = useState("");
  const { data: tickets, isLoading } = useListTickets();
  const [, setLocation] = useLocation();

  const filteredTickets = tickets?.filter(t => 
    t.title.toLowerCase().includes(search.toLowerCase()) || 
    t.roughInput.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Layout>
      <div className="max-w-4xl mx-auto w-full p-6 h-full flex flex-col gap-6">
        <header className="flex flex-col gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">History</h1>
            <p className="text-muted-foreground text-sm font-mono mt-1">Archive of generated prompts.</p>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by title or content..." 
              className="pl-9 font-mono bg-card border-border focus-visible:ring-primary"
              value={search}
              onChange={e => setSearch(e.target.value)}
              data-testid="input-search-history"
            />
          </div>
        </header>

        <div className="flex-1 overflow-auto">
          {isLoading ? (
            <div className="flex flex-col gap-3">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-24 w-full bg-muted/50 rounded-md" />
              ))}
            </div>
          ) : !filteredTickets?.length ? (
            <div className="flex flex-col items-center justify-center h-64 text-center border border-dashed border-border rounded-lg bg-card/50">
              <FileText className="w-10 h-10 text-muted-foreground mb-3 opacity-50" />
              <h3 className="font-medium text-foreground">No tickets found</h3>
              <p className="text-sm text-muted-foreground font-mono mt-1">
                {search ? "Adjust your search terms" : "Generate your first ticket"}
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {filteredTickets.map(ticket => (
                <div 
                  key={ticket.id}
                  onClick={() => setLocation(`/ticket/${ticket.id}`)}
                  className="group flex flex-col md:flex-row md:items-center justify-between p-4 rounded-md border border-border bg-card hover:border-primary/50 hover:shadow-[0_0_15px_rgba(var(--primary),0.1)] cursor-pointer transition-all"
                  data-testid={`card-ticket-${ticket.id}`}
                >
                  <div className="flex flex-col gap-1 overflow-hidden pr-4">
                    <h3 className="font-semibold text-foreground truncate group-hover:text-primary transition-colors">
                      {ticket.title}
                    </h3>
                    <p className="text-xs text-muted-foreground font-mono truncate">
                      {ticket.roughInput.substring(0, 100)}...
                    </p>
                  </div>
                  <div className="flex items-center gap-4 mt-3 md:mt-0 shrink-0">
                    <span className="text-xs font-mono text-muted-foreground bg-muted px-2 py-1 rounded">
                      {format(new Date(ticket.createdAt), "MMM d, HH:mm")}
                    </span>
                    <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}